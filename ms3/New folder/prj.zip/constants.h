#ifndef SENECA_CONSTANTS_H
#define SENECA_CONSTANTS_H

namespace seneca {
   const size_t MaximumNumberOfMenuItems = 20u;
}

#endif // !SENECA_CONSTANTS_H
